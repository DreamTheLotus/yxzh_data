var type = document.querySelector("#type")
var now_level = document.querySelector("#now_level")
var max_level = document.querySelector("#max_level")
var have_love = document.querySelector("#have_love")
var have_courage = document.querySelector("#have_courage")
var have_hope = document.querySelector("#have_hope")
var need_love = document.querySelector("#need_love")
var need_courage = document.querySelector("#need_courage")
var need_hope = document.querySelector("#need_hope")
var attribute
var virtue_list = [{
	"name": "物理伤害",
	"virtue": [20, 5, 10],
	"level": 500
}, {
	"name": "法术伤害",
	"virtue": [10, 20, 5],
	"level": 500
}, {
	"name": "火焰伤害",
	"virtue": [5, 10, 20],
	"level": 500
}, {
	"name": "雷电伤害",
	"virtue": [20, 5, 10],
	"level": 500
}, {
	"name": "毒素伤害",
	"virtue": [10, 20, 5],
	"level": 500
}, {
	"name": "寒冷伤害",
	"virtue": [5, 10, 20],
	"level": 500
}, {
	"name": "远程命中",
	"virtue": [40, 10, 20],
	"level": 400
}, {
	"name": "近程命中",
	"virtue": [20, 40, 10],
	"level": 400
}, {
	"name": "远程回避",
	"virtue": [15, 30, 60],
	"level": 200
}, {
	"name": "近程回避",
	"virtue": [60, 15, 30],
	"level": 200
}, {
	"name": "护甲",
	"virtue": [20, 5, 10],
	"level": 500
}, {
	"name": "最大生命",
	"virtue": [10, 20, 5],
	"level": 500
}, {
	"name": "物理伤害减免",
	"virtue": [60, 15, 30],
	"level": 200
}, {
	"name": "法术伤害减免",
	"virtue": [30, 60, 15],
	"level": 200
}, {
	"name": "火焰伤害减免",
	"virtue": [15, 30, 60],
	"level": 200
}, {
	"name": "雷电伤害减免",
	"virtue": [60, 15, 30],
	"level": 200
}, {
	"name": "毒素伤害减免",
	"virtue": [30, 60, 15],
	"level": 200
}, {
	"name": "寒冷伤害减免",
	"virtue": [15, 30, 60],
	"level": 200
}, {
	"name": "物理伤害系数",
	"virtue": [40, 10, 20],
	"level": 400
}, {
	"name": "法术伤害系数",
	"virtue": [20, 40, 10],
	"level": 400
}, {
	"name": "火焰伤害系数",
	"virtue": [10, 20, 40],
	"level": 400
}, {
	"name": "雷电伤害系数",
	"virtue": [40, 10, 20],
	"level": 400
}, {
	"name": "毒素伤害系数",
	"virtue": [20, 40, 10],
	"level": 400
}, {
	"name": "寒冷伤害系数",
	"virtue": [10, 20, 40],
	"level": 400
}, {
	"name": "致晕",
	"virtue": [40, 10, 20],
	"level": 200
}, {
	"name": "眩晕抵抗",
	"virtue": [20, 40, 10],
	"level": 200
}, {
	"name": "冰冻概率",
	"virtue": [10, 20, 40],
	"level": 200
}, {
	"name": "冰冻抗性",
	"virtue": [40, 10, 20],
	"level": 200
}, {
	"name": "物理伤害吸收",
	"virtue": [10, 20, 5],
	"level": 500
}, {
	"name": "法术伤害吸收",
	"virtue": [5, 10, 20],
	"level": 500
}, {
	"name": "火焰伤害吸收",
	"virtue": [20, 5, 10],
	"level": 500
}, {
	"name": "雷电伤害吸收",
	"virtue": [10, 20, 5],
	"level": 500
}, {
	"name": "毒素伤害吸收",
	"virtue": [5, 10, 20],
	"level": 500
}, {
	"name": "寒冷伤害吸收",
	"virtue": [20, 5, 10],
	"level": 500
}, {
	"name": "韧性",
	"virtue": [15, 30, 60],
	"level": 100
}]
var select = virtue_list[0]
var have_virtue = {
	level: 0,
	love: 0,
	courage: 0,
	hope: 0
}

//type.innerHTML = write_attribute_document()
attribute = document.querySelectorAll(".attribute")
init()


for (let index in attribute) {
	attribute[index].onclick = click
}


function write_attribute_document() {
	var cache = ""
	for (let i = 0; i < virtue_list.length; i++) {
		cache += `<span class = "attribute">${virtue_list[i].name}</span>`
	}
	return cache
}

function click() {
	console.log(this.innerHTML)
	for (let i = 0; i < virtue_list.length; i++) {
		if (virtue_list[i].name == this.innerHTML) {
			select = virtue_list[i]
			attribute[i].style.background = "#0000ff"
		} else {
			attribute[i].style.background = "#5555ff"
		}
	}
	max_level.value = select.level
	have_virtue.level = 0
	load_need_virute(select.level)

}

now_level.addEventListener("keyup", function() {
	var level = 0
	console.log(`现在的数值为：${now_level.value}`)
	if (now_level.value == "") {
		level = 0
	} else {
		if (parseInt(now_level.value) > parseInt(max_level.value)) {
			level = max_level.value
			now_level.value = level
		} else {
			level = now_level.value
		}

	}
	have_virtue.level = level
	load_need_virute(max_level.value)
})

max_level.addEventListener("keyup", function() {
	var level = 0
	if (max_level.value == "") {
		level = 0
	} else {
		if (parseInt(max_level.value) > select.level) {
			level = select.level
			max_level.value = level
		} else {
			level = max_level.value
		}
	}
	load_need_virute(max_level.value)
})

have_love.addEventListener("keyup", function() {
	if (have_love.value < 0) {
		have_love.value = 0
	} else {
		have_virtue.love = have_love.value
	}
	load_need_virute(max_level.value)
})
have_courage.addEventListener("keyup", function() {
	if (have_courage.value < 0) {
		have_courage.value = 0
	} else {
		have_virtue.courage = have_courage.value
	}
	load_need_virute(max_level.value)
})
have_hope.addEventListener("keyup", function() {
	if (have_hope.value < 0) {
		have_hope.value = 0
	} else {
		have_virtue.hope = have_hope.value
	}
	load_need_virute(max_level.value)
})
//10

function compute_virtue(max_level, virtue) {
	var need_virtues = [0, 0, 0]
	var order = get_small_virtue(virtue).order
	var small = get_small_virtue(virtue).small
	var compute_small = 0
	var cache_type = select.name.substr(select.name.length - 2, 2)
	for (let i = 0; i < max_level; i++) {
		if (cache_type == "系数" || cache_type == "命中" || cache_type == "致晕" || cache_type == "抵抗" || cache_type == "概率" ||
			cache_type == "抗性") {
			if (i % 2 == 0) { //取模0时应该为10
				compute_small = small * (parseInt(i / 2) + 1) + small * (parseInt(i / 2)) / 2
			} else { //取模1时应该为5
				compute_small = small * (parseInt(i / 2) + 2) + small * (parseInt(i / 2) - 1) / 2
			}
		} else {
			compute_small = small * (i + 1)
		}
		if (compute_small < 1500) {
			for (let j = 0; j < order.length; j++) {
				if (order[j] == 1) {
					need_virtues[j] += compute_small
				} else if (order[j] == 2) {
					need_virtues[j] += compute_small * 2
				} else if (order[j] == 3) {
					need_virtues[j] += compute_small * 4
				}
			}
		} else {
			for (let j = 0; j < order.length; j++) {
				if (order[j] == 1) {
					need_virtues[j] += 1500
				} else if (order[j] == 2) {
					need_virtues[j] += 3000
				} else if (order[j] == 3) {
					need_virtues[j] += 6000
				}
			}
		}
	}
	return need_virtues
}
//10-15-25-30

function get_small_virtue(virtue) {
	var small = 100
	var order = [0, 0, 0]
	var order_cache = 0
	for (let i = 0; i < virtue.length; i++) {
		if (virtue[i] < small) {
			small = virtue[i]
			order_cache = i
		}
	}
	order[order_cache] = 1
	order_cache = 0
	for (let i = 0; i < virtue.length; i++) {
		if (small * 2 == virtue[i]) {
			order[order_cache] = 2
		} else if (small * 4 == virtue[i]) {
			order[order_cache] = 3
		}
		order_cache++
	}
	return {
		order,
		small
	}
}

function init() {
	attribute[0].style.background = "#0000ff"
	max_level.value = select.level
	load_need_virute(select.level)
}

function load_need_virute(level) {
	need_love.innerHTML =
		`爱：${compute_virtue(level, select.virtue)[0] - have_virtue.love-compute_virtue(have_virtue.level,select.virtue)[0]}`
	need_courage.innerHTML =
		`勇气：${compute_virtue(level, select.virtue)[1] - have_virtue.courage-compute_virtue(have_virtue.level,select.virtue)[1]}`
	need_hope.innerHTML =
		`希望：${compute_virtue(level, select.virtue)[2] - have_virtue.hope-compute_virtue(have_virtue.level,select.virtue)[2]}`
}
